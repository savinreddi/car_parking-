document.addEventListener('DOMContentLoaded', function() {
    // Form Validation for Login
    const loginForm = document.querySelector('form[action="/login"]');
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            if (username === "" || password === "") {
                event.preventDefault(); // Prevent form submission
                alert("Both fields are required for login.");
            }
        });
    }

    // Form Validation for Signup
    const signupForm = document.querySelector('form[action="/signup"]');
    if (signupForm) {
        signupForm.addEventListener('submit', function(event) {
            const username = document.getElementById('username').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            if (username === "" || email === "" || password === "") {
                event.preventDefault(); // Prevent form submission
                alert("All fields are required for signup.");
            } else {
                const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
                if (!email.match(emailPattern)) {
                    event.preventDefault();
                    alert("Please enter a valid email address.");
                }
            }
        });
    }

    // Search Form Validation
    const searchForm = document.querySelector('form[action="/search"]');
    if (searchForm) {
        searchForm.addEventListener('submit', function(event) {
            const location = document.getElementById('location').value;
            if (location === "") {
                event.preventDefault(); // Prevent form submission
                alert("Please enter a location to search for parking slots.");
            }
        });
    }

    // Booking Slot Form
    const bookingForms = document.querySelectorAll('form[action^="/book/"]');
    bookingForms.forEach(function(form) {
        form.addEventListener('submit', function(event) {
            // You could implement more logic here if necessary
            const slotId = form.querySelector('input[name="slot_id"]').value;
            if (!slotId) {
                event.preventDefault();
                alert("No slot selected for booking.");
            }
        });
    });

    // Cancel Booking functionality
    const cancelBookingForms = document.querySelectorAll('form[action^="/cancel/"]');
    cancelBookingForms.forEach(function(form) {
        form.addEventListener('submit', function(event) {
            const confirmation = confirm("Are you sure you want to cancel this booking?");
            if (!confirmation) {
                event.preventDefault(); // Prevent form submission
            }
        });
    });
});
