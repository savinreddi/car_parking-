from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Set a secret key for session management

# Database Helper Functions
def get_db_connection():
    conn = sqlite3.connect('user/database/user_db.sqlite')
    conn.row_factory = sqlite3.Row
    return conn

# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('search'))
    return render_template('login_signup/login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()

        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            flash("Login successful!", "success")
            return redirect(url_for('search'))
        else:
            flash("Invalid credentials, please try again.", "danger")
            return redirect(url_for('login'))

    return render_template('login_signup/login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        hashed_password = generate_password_hash(password, method='sha256')

        conn = get_db_connection()
        conn.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
                     (username, email, hashed_password))
        conn.commit()
        conn.close()

        flash("Signup successful! Please login.", "success")
        return redirect(url_for('login'))

    return render_template('login_signup/signup.html')

@app.route('/search', methods=['GET', 'POST'])
def search():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        location = request.form['location']
        # Example: Fetch parking slots based on location
        conn = get_db_connection()
        slots = conn.execute('SELECT * FROM parking_slots WHERE location LIKE ?', ('%' + location + '%',)).fetchall()
        conn.close()

        return render_template('search/search.html', slots=slots)

    return render_template('search/search.html')

@app.route('/book/<int:slot_id>', methods=['POST'])
def book(slot_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    user_id = session['user_id']
    conn.execute('INSERT INTO bookings (user_id, slot_id) VALUES (?, ?)', (user_id, slot_id))
    conn.commit()
    conn.close()

    flash("Booking successful!", "success")
    return redirect(url_for('search'))

@app.route('/booking_history')
def booking_history():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    user_id = session['user_id']
    bookings = conn.execute('SELECT * FROM bookings WHERE user_id = ?', (user_id,)).fetchall()
    conn.close()

    return render_template('search/booking_history.html', bookings=bookings)

@app.route('/cancel/<int:booking_id>', methods=['POST'])
def cancel(booking_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    conn.execute('DELETE FROM bookings WHERE id = ?', (booking_id,))
    conn.commit()
    conn.close()

    flash("Booking cancelled successfully!", "success")
    return redirect(url_for('booking_history'))

if __name__ == "__main__":
    app.run(debug=True)
