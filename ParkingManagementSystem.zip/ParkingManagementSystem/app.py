from flask import Flask
from admin.backend.admin_routes import admin_bp  # Import the admin blueprint

app = Flask(__name__)

# Register the admin blueprint with a URL prefix '/admin'
app.register_blueprint(admin_bp, url_prefix='/admin')

# Root route
@app.route('/')
def home():
    return 'Welcome to the Parking Management System'

if __name__ == '__main__':
    app.secret_key = '6eD6pg7syqDh97MaXu74IMI4ShsixBTd'  # Secret key for session management
    app.run(debug=True)
