import sqlite3

# Connect to the SQLite database
def get_db_connection():
    conn = sqlite3.connect('admin/database/admin_db.sqlite')  # Path to your SQLite database
    conn.row_factory = sqlite3.Row  # This allows us to access columns by name
    return conn

# Function to add a parking slot to the database
def add_parking_slot(location, total_slots, available_slots):
    conn = get_db_connection()
    conn.execute('INSERT INTO parking_slots (location, total_slots, available_slots) VALUES (?, ?, ?)',
                 (location, total_slots, available_slots))
    conn.commit()
    conn.close()

# Function to get all parking slots from the database
def get_all_parking_slots():
    conn = get_db_connection()
    slots = conn.execute('SELECT * FROM parking_slots').fetchall()
    conn.close()
    return slots

# Function to get all bookings from the database
def get_all_bookings():
    conn = get_db_connection()
    bookings = conn.execute('SELECT * FROM bookings').fetchall()
    conn.close()
    return bookings

# Function to add a new user (admin or customer)
def add_user(username, password, role):
    conn = get_db_connection()
    conn.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', 
                 (username, password, role))
    conn.commit()
    conn.close()

# Function to check if admin credentials are valid
def check_admin_credentials(username, password):
    conn = get_db_connection()
    admin = conn.execute('SELECT * FROM admins WHERE username = ? AND password = ?', 
                         (username, password)).fetchone()
    conn.close()
    return admin
