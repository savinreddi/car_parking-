from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from admin.backend.database import get_db_connection

# Define the Blueprint for admin
admin_bp = Blueprint('admin_bp', __name__, template_folder='templates')

# Route for admin login page
@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Placeholder for actual admin authentication
        if username == 'admin' and password == 'password':  # Example check
            session['admin'] = username
            return redirect(url_for('admin_bp.dashboard'))
        else:
            flash('Invalid credentials. Please try again.')

    return render_template('login.html')

# Route for admin dashboard
@admin_bp.route('/dashboard')
def dashboard():
    if 'admin' not in session:
        return redirect(url_for('admin_bp.login'))

    conn = get_db_connection()
    slots = conn.execute('SELECT * FROM parking_slots').fetchall()
    bookings = conn.execute('SELECT * FROM bookings').fetchall()
    conn.close()

    return render_template('dashboard.html', slots=slots, bookings=bookings)

# Route for managing parking slots
@admin_bp.route('/manage_slots', methods=['GET', 'POST'])
def manage_slots():
    if 'admin' not in session:
        return redirect(url_for('admin_bp.login'))

    if request.method == 'POST':
        slot_number = request.form['slot_number']
        availability = request.form['availability']

        # Add parking slot to database
        conn = get_db_connection()
        conn.execute('INSERT INTO parking_slots (slot_number, availability) VALUES (?, ?)', 
                     (slot_number, availability))
        conn.commit()
        conn.close()

        flash('Parking slot added successfully!')
        return redirect(url_for('admin_bp.manage_slots'))

    conn = get_db_connection()
    slots = conn.execute('SELECT * FROM parking_slots').fetchall()
    conn.close()

    return render_template('manage_slots.html', slots=slots)

# Route to view all bookings
@admin_bp.route('/view_bookings')
def view_bookings():
    if 'admin' not in session:
        return redirect(url_for('admin_bp.login'))

    conn = get_db_connection()
    bookings = conn.execute('SELECT * FROM bookings').fetchall()
    conn.close()

    return render_template('view_bookings.html', bookings=bookings)

# Route to handle logout
@admin_bp.route('/logout')
def logout():
    session.pop('admin', None)
    return redirect(url_for('admin_bp.login'))
