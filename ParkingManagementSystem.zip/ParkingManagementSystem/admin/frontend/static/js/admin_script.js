document.addEventListener('DOMContentLoaded', function () {
    // Admin Dashboard Scripts

    // Manage Parking Slots Form Validation and Submission
    const manageSlotForm = document.querySelector('#manage-slot-form');
    if (manageSlotForm) {
        manageSlotForm.addEventListener('submit', function (event) {
            const location = document.getElementById('location').value;
            const totalSlots = document.getElementById('total_slots').value;
            const availableSlots = document.getElementById('available_slots').value;

            // Simple validation
            if (location === '' || totalSlots === '' || availableSlots === '') {
                alert('All fields are required!');
                event.preventDefault();
                return;
            }

            if (parseInt(availableSlots) > parseInt(totalSlots)) {
                alert('Available slots cannot be more than total slots!');
                event.preventDefault();
                return;
            }
        });
    }

    // Handling Parking Slot Deletion (for Manage Slots page)
    const deleteButtons = document.querySelectorAll('.delete-slot');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function (event) {
            const slotId = button.getAttribute('data-slot-id'); // Ensure correct attribute is used
            const confirmation = confirm('Are you sure you want to delete this parking slot?');
            if (confirmation) {
                deleteParkingSlot(slotId);
            }
        });
    });

    // Function to send a DELETE request to the backend
    function deleteParkingSlot(slotId) {
        fetch(`/admin/delete_slot/${slotId}`, {
            method: 'DELETE',
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Parking slot deleted successfully.');
                location.reload();  // Refresh the page to reflect the change
            } else {
                alert('Failed to delete the parking slot.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting the parking slot.');
        });
    }

    // Admin View Bookings Page - Mark booking as "Expired" or "Confirmed"
    const bookingRows = document.querySelectorAll('table tbody tr');
    bookingRows.forEach(row => {
        const statusCell = row.querySelector('td:nth-child(4)'); // Assuming status is in the 4th column
        const status = statusCell ? statusCell.textContent.trim() : '';

        if (status === 'Expired') {
            row.style.backgroundColor = '#f8d7da'; // Highlight expired bookings in red
        } else if (status === 'Confirmed') {
            row.style.backgroundColor = '#d4edda'; // Highlight confirmed bookings in green
        }
    });

    // View Bookings: Show details of the booking in a modal (if applicable)
    const viewDetailsButtons = document.querySelectorAll('.view-details');
    viewDetailsButtons.forEach(button => {
        button.addEventListener('click', function () {
            const bookingId = button.getAttribute('data-booking-id');
            showBookingDetails(bookingId);
        });
    });

    // Function to show booking details in a modal (or redirect to details page)
    function showBookingDetails(bookingId) {
        fetch(`/admin/get_booking_details/${bookingId}`)
        .then(response => response.json())
        .then(data => {
            // Assuming data contains details like booking status, location, user info
            if (data.success) {
                const bookingDetails = data.booking;
                // Populate modal or display the details on the page
                const modal = document.getElementById('booking-details-modal');
                modal.querySelector('.modal-body').innerHTML = `
                    <p><strong>Location:</strong> ${bookingDetails.location}</p>
                    <p><strong>Status:</strong> ${bookingDetails.status}</p>
                    <p><strong>User:</strong> ${bookingDetails.user_name}</p>
                    <p><strong>Booking Time:</strong> ${bookingDetails.booking_time}</p>
                `;
                modal.style.display = 'block';  // Show the modal
            } else {
                alert('Failed to fetch booking details.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while fetching booking details.');
        });
    }

    // Close the modal (if applicable)
    const closeModalButton = document.querySelector('.close-modal');
    if (closeModalButton) {
        closeModalButton.addEventListener('click', function () {
            const modal = document.getElementById('booking-details-modal');
            modal.style.display = 'none';
        });
    }
});
