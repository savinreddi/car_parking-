import os

# Configuration for the app and database
class Config:
    SECRET_KEY = '6eD6pg7syqDh97MaXu74IMI4ShsixBTd'  # Ensure this is a random secret key
    DATABASE = 'backend/database/admin_db.sqlite'  # Path to the SQLite database
    SQLALCHEMY_TRACK_MODIFICATIONS = False
